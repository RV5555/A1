package com.example.personalmanagementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {
ListView FriendView1;
ArrayList list;
Button addbtn1;
EditText fname, lname,age,addr;
ArrayAdapter<String> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        FriendView1 = (ListView) findViewById(R.id.FriendView1);
        addbtn1=(Button) findViewById(R.id.addbtn1);
        fname=(EditText) findViewById(R.id.fname);
        lname=(EditText) findViewById(R.id.lname);
        age=(EditText) findViewById(R.id.age);
        addr=(EditText)findViewById(R.id.addr);

        list=new ArrayList<String>();
        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,list);
        addbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Names =fname.getText().toString();
                list.add(Names);
                FriendView1.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();

            }
        });





    }

    public void showToast(View view) {

        Toast.makeText(MainActivity3.this, "\n You have added a friend in your record",
                Toast.LENGTH_LONG).show();
    }

    public void moveTask(View view) {
        Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
        startActivity(intent);

    }
    public void moveFriend(View view) {
        Intent intent = new Intent(MainActivity3.this, MainActivity5.class);
        startActivity(intent);
    }
}



